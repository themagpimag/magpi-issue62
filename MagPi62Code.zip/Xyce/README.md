# Xyce
Build instructions for Xyce 6.7 on a Raspberry Pi Model 3B

Read the pdf for full instructions
